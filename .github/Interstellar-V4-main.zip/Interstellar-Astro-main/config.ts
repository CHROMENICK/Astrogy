import type { Config } from "@/types/config";
const config: Config = {
  // config options here...
};
export default config;
